import logo from './logo.svg';
import './App.css';
import BoxForm from './components/boxForm';

function App() {
  return (
    <div className="App">
      <BoxForm />
    </div>
  );
}

export default App;
